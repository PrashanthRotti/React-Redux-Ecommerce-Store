import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";

// pages
import AllProductsPage from "./pages/AllProductsPage.js";

import CartSidebar from './components/CartSidebar/CartSidebar.js';
import Navbar from './components/Navbar/Navbar.js';
import SideBar from "./components/Sidebar/Sidebar.js";
import Footer from "./components/Footer/Footer.js";
import HomePage from "./pages/HomePage.js";
import ShirtsPage from "./pages/ShirtsPage.js";
import ShoesPage from "./pages/ShoesPage.js";
import HeadPhonesPage from "./pages/HeadPhonesPage.js";
import AdminBar from "./components/AdminBar/AdminBar.js";

const App = () => {
  return (
    <div className="App">
      <Navbar />
      <CartSidebar />
      <SideBar />
      <AdminBar />
      <BrowserRouter>
        <Routes>
          <Route path="/*" element={<HomePage />} />
          <Route path="/products" element={<AllProductsPage />} />
          <Route path="/shirts" element={<ShirtsPage />} />
          <Route path="/shoes" element={<ShoesPage />} />
          <Route path="/headphones" element={<HeadPhonesPage />} />
        </Routes>
      </BrowserRouter>
      <Footer />
    </div>
  );
}

export default App;
