import { combineReducers } from "redux";

import productReducer from './products/products_reducers';
import sidebarReducer from './sidebar/sidebar_reducers';
import adminReducer from './admin/admin_reducers';

const rootReducer = combineReducers({
    products: productReducer,
    sidebar: sidebarReducer,
    admin: adminReducer
})

export default rootReducer;
