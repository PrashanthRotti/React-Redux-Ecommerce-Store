import {
    TOGGLE_ADMIN_BAR
} from "./admin_types";

export const toggleAdminBar = () => {
    return { type: TOGGLE_ADMIN_BAR }
};
