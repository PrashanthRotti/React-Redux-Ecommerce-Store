import {
    TOGGLE_ADMIN_BAR
} from "./admin_types";

const initialState = {
    toggleAdminBar: false
};

const adminReducer = (state = initialState, { type }) => {
    switch (type) {
        case TOGGLE_ADMIN_BAR:
            return {
                ...state,
                toggleAdminBar: !state.toggleAdminBar
            }

        default:
            return state
    }
}

export default adminReducer;
