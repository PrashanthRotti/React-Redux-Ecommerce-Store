const ErrorPage = () => {
    return (
      <div>
        <h1>ErrorPage</h1>
      </div>
    );
  };
  
  export default ErrorPage;
  