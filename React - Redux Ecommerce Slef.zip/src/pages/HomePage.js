import React from 'react';
import Categories from '../components/Categories/Categories';
import MainBanner from '../components/MainBanner/MainBanner';

const Home = () => {
    return (
        <React.Fragment>
            <MainBanner />
            <Categories />
        </React.Fragment>
    )
}

export default Home;
