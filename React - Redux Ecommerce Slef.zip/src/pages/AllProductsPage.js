import { useEffect, Fragment } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../redux/products/products_actions";
import AllProducts from "../components/AllProducts/AllProducts.js";
import productsBanner from "../assets/images/products-banner.jpg"
import Banner from "../components/Banner/Banner";

const AllProductsPage = () => {
    const { products } = useSelector((state) => state.products);
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchProducts())
    }, [dispatch])

    return (
        <Fragment>
            <Banner image={productsBanner} />
            <AllProducts products={products} />
        </Fragment>
    )
}

export default AllProductsPage;
