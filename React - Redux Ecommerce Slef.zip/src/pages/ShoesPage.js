import React from "react";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import Product from "../components/Product/Product.js";
import Banner from "../components/Banner/Banner.js";
import Title from "../components/Title/Title.js";
import Hero from "../components/Hero/Hero.js";

import { fetchProducts } from "../redux/products/products_actions";

import shoesBanner from "../assets/images/shoes-banner.jpg";
import Loading from "../components/loading/loading.js";

const ShoesPage = () => {
    const { products } = useSelector(state => state.products);
    const dispatch = useDispatch();
    const loading = useSelector(state => state.products.loading);

    useEffect(() => {
        dispatch(fetchProducts())
    }, [dispatch]);

    const [visible, setVisible] = useState(3);

    const showmoreProducts = () => {
        setVisible(oldValue => oldValue + 3)
    }

    const shoesProduct = products.filter(items => items.title === "shoes");

    return (
        <React.Fragment>
            {loading ?
                <Loading />
                :
                <React.Fragment>
                    <Banner image={shoesBanner} />
                    <div className="container py-5">
                        <Title title="SHOES PRODUCTS" />
                        <div className="row">
                            {shoesProduct.slice(0, visible).map((product) => {
                                return (
                                    <div
                                        key={product.id}
                                        className="col-10 col-md-6 col-lg-4 mx-auto"
                                    >
                                        <Product product={product} />
                                    </div>
                                )
                            })}
                        </div>

                        {visible === shoesProduct.length ? null : (
                            <div
                                style={{ textAlign: 'center' }}
                                className="col-10 mx-auto pt-3 py-5"
                            >
                                <button onClick={() => showmoreProducts()} className="btn btn-grey">
                                    Show More
                                </button>
                            </div>
                        )}
                    </div>

                    <Hero
                        subtitleHeading="extra"
                        subtitleFooter="online"
                        offer="30% off"
                        title="lifestyle collection"
                        text="free shipping on orders over $99"
                    />
                </React.Fragment>
            }
        </React.Fragment>
    )
}

export default ShoesPage;
