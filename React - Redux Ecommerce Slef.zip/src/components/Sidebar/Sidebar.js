import { useSelector, useDispatch } from "react-redux";
import { navbarLinks } from "../../utils/navbarLinks.js";
import { closeSideBar } from "../../redux/sidebar/sidebar_actions.js";
import SocialIcons from "../SocialIcons/SocialIcons.js";

import welcome from '../../assets/images/welcome.png';

import "./Sidebar.scss";

const SideBar = () => {
    const { sideBarOpen } = useSelector((state) => state.sidebar);
    const dispatch = useDispatch();

    return (
        <div className={sideBarOpen ? 'sidebar sidebar--show' : 'sidebar'}>
            <div
                className={`${sideBarOpen
                        ? 'sidebar__content sidebar__content--show'
                        : 'sidebar__content'
                    }`}
            >
                <ul className="sidebar__links">
                    {navbarLinks && navbarLinks.map((link) => {
                        const { id, text, path } = link;
                        return (
                            <li key={id}>
                                <a
                                    onClick={() => dispatch(closeSideBar())}
                                    href={path}
                                    className="sidebar__link"
                                >
                                    {text}
                                </a>
                            </li>
                        )
                    })}
                </ul>
                <div className="sidebar__image-container">
                    <img src={welcome} alt="welcome logo" className="sidebar__image" />
                </div>
                <div className="sidebar__footer">
                    <SocialIcons />
                </div>
            </div>
        </div>
    )
}

export default SideBar;