import React, { useState } from "react";
import { useSelector } from "react-redux";
import Loading from "../loading/loading.js";
import Product from "../Product/Product.js";
import Title from "../Title/Title.js";

const AllProducts = ({ products }) => {
    const { loading } = useSelector((state) => state.products);
    const [visible, setVisible] = useState(6);

    const showMoreProducts = () => {
        setVisible((oldValue) => oldValue + 3);
    };

    if (loading) {
        return (
            <Loading />
        );
    }

    return (
        <section className="py-5">
            <div className="container">
                <Title title="OUR PRODUCTS" />
                <div className="row">
                    {products.slice(0, visible).map((product) => {
                        return (
                            <div
                                key={product.id}
                                className="col-10 col-md-6 col-lg-4 mx-auto"
                            >
                                <Product product={product} />
                            </div>
                        );
                    })}
                </div>
                {visible === products.length ? null : (
                    <div className="row">
                        <div
                            style={{ textAlign: 'center' }}
                            className="col-10 mx-auto pt-3"
                        >
                            <button onClick={showMoreProducts} className="btn btn-grey">
                                show more
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </section>
    );
}

export default AllProducts;
