import { useDispatch, useSelector } from "react-redux";
import { CgCloseO } from 'react-icons/cg';

import { toggleAdminBar } from "../../redux/admin/admin_actions";

import "./AdminBar.scss";

const AdminBar = () => {
    const isAdminOpen = useSelector((state) => state.admin.toggleAdminBar);
    const dispatch = useDispatch();

    return (
        <div
            className={
                isAdminOpen ? 'admin-overlay admin-overlay--show' : 'admin-overlay'
            }
        >
            <div
                className={
                    isAdminOpen ? 'admin-sidebar admin-sidebar--show' : 'admin-sidebar'
                }
            >
                <div className="admin-sidebar__heading">
                    <p className="admin-sidebar__title">Login</p>
                    <span className="admin-sidebar__close">
                        <CgCloseO onClick={() => dispatch(toggleAdminBar())} />
                    </span>
                </div>
                <label for="uname"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="uname" required />

                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="psw" required />
                <button class="btn btn-black" type="submit">Login</button>
            </div>
        </div>
    )
}

export default AdminBar;
