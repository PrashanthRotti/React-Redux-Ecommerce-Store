import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { BiUser } from 'react-icons/bi';
import { CgShoppingBag } from 'react-icons/cg';
import { FaBars } from 'react-icons/fa';

// import navbar links from utils
import { navbarLinks } from '../../utils/navbarLinks';

// navbar styles
import './Navbar.scss';

// import logo from assets
import logo from '../../assets/images/hogash-logo-black.png';

import {
    toggleSideCart,
    toggleSideBar
} from '../../redux/sidebar/sidebar_actions.js';

import { toggleAdminBar } from "../../redux/admin/admin_actions.js"

import { useState } from "react";

const Navbar = () => {
    const { cart } = useSelector((state) => state.products);
    const dispatch = useDispatch();
    const [cartCount, setCartCount] = useState(0);

    useEffect(() => {
        let count = 0;
        cart.forEach(item => {
            count += item.qty;
        });

        setCartCount(count);
    }, [cart, cartCount]);

    return (
        <header className="site-header">
            {/* bootstrap container class */}
            <div className="container">
                {/* navbar */}
                <nav className="site-header__navbar">
                    {/* navbar logo & links */}
                    <div className="site-header__navbar-nav">
                        <div className="site-header__logo-container">
                            {/* navbar logo */}
                            <a href="/">
                                <img
                                    src={logo}
                                    alt="company logo"
                                    className="site-header__logo"
                                />
                            </a>
                        </div>
                        {/* navbar links */}
                        <ul className="site-header__links">
                            {/* map through navbarLinks array */}
                            {navbarLinks.map((link) => {
                                const { id, text, path } = link;
                                return (
                                    <li key={id}>
                                        <a href={path} className="site-header__link">
                                            {text}
                                        </a>
                                    </li>
                                );
                            })}
                        </ul>
                    </div>
                    {/* navbar login icon & cart icon */}
                    <div className="site-header__icons">
                        <ul className="site-header__icons-list">
                            <li className="site-header__icons-item">
                                <a style={{ color: '#000' }}>
                                    <BiUser
                                        onClick={() => dispatch(toggleAdminBar())}
                                        className="site-header__icon"                                        
                                    />
                                </a>
                            </li>
                            <li className="site-header__icons-item">
                                <CgShoppingBag
                                    onClick={() => dispatch(toggleSideCart())}
                                    style={{ cursor: 'pointer' }}
                                />
                                <span className="site-header__cart-count">{cartCount}</span>
                            </li>
                            <li className="site-header__icons-item">
                                <FaBars
                                    className="site-header__toggle"
                                    onClick={() => dispatch(toggleSideBar())}
                                />
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </header>
    )
}

export default Navbar;
